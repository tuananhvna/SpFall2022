package com.example.helloworld.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

// @CONTROLLER ANNOTAION (ANNOTATIONS START WITH @)
// LET'S SPRING NOW THAT THIS FILE WILL HANDLE WEB TRAFFIC
@Controller
@ResponseBody
public class HelloController {
	// ANNOTATION REQUESTMAPPING TELLS WHICH ENDPOINTS ARE "LISTENED" TO
	@RequestMapping("/index")
	public String index() {
		return "This is the main page";
	}

	@RequestMapping("/contact")
	public String contact() {
		return "This is the contact page";
	}

	@RequestMapping("/hello")
	public String hello(@RequestParam(name = "location") String location, @RequestParam(name = "name") String name) {
		return "Welcome to the " + location + " " + name + "!";
	}
}
